//Display box when data entered successfulyl 
$("#add_entry").submit(function(event){
    alert("Data Inserted Successfully")
})

//Prevent default actions for page refresh
$("#update_entry").submit(function(event){
    event.preventDefault();

    var unindexed_array = $(this).serializeArray();
    var data ={}

    $.map(unindexed_array, function(n,i){
        data[n['name']] = n['value']
    })
    console.log(unindexed_array)

//Variable to hold requests that will send data  
    var request = {
        "url" : `http://localhost:3000/api/entry/${data.id}`,
        "method" : "PUT",
        "data" : data
    }
    //Another alret to let user know data updated successfully
    $.ajax(request).done(function(response){
        alert("Data updated successfully");
    })
})


if(window.location.pathname =="/"){
    $ondelete = $(".table tbody td a.delete")
    $ondelete.click(function(){
        var id = $(this).attr("data-id")

//Variable to hold request to delete an entry
        var request = {
            "url" : `http://localhost:3000/api/entry/${id}`,
            "method" : "DELETE",
        }
        //Confirmation prompt to prevent accidentally deletion
        if(confirm("Are you sure you want to delete this record?")){
            $.ajax(request).done(function(response){
                alert("Data Deleted successfully");
                location.reload()
            })
        }

    })
}