//Library needed for mongoose functions
const mongoose = require('mongoose');

const connectDB = async () =>{
    try{
        //mongodb connection string
        const con = await mongoose.connect(process.env.MONGO_URI, {
            useUnifiedTopology:true
        })

        console.log(`MongoDB connected : ${con.connection.host}`);
    }

    //Catch and log any errors found and print the errors to console
    catch(err){
        console.log(err);
        process.exit(1);

    }
}

//Export the module to be used outside connection.js
module.exports = connectDB