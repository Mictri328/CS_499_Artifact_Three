//Library needed to run mongoose functions
const mongoose = require('mongoose');


//Set up Database schema
var schema = new mongoose.Schema({
    first_name:{
    type:String,
    required:true
},

    last_name:{
    type:String,
    required:true
},

    city:{
    type:String,
    required:true
}, 

    county:{
    type:String,
    required:true   
},

    state:{
    type:String,
    required:true

},

    zip:{
    type:String,
    required:true

},

    Restaurant:{
    type:String,
    required:true

},

    RES_VISITS:{
    type:String,
    required:true

},

    Webstore_Spend:{
    type:String,
    required:true

},

    WEB_VISITS:{
    type:String,
    required:true

},

    Age:{
    type:String,
    required:true

},

    Income:{
    type:String,
    required:true
    },

    Married_YN:String,
    status:String

})

//create constant to hold all the data in schema
const Userdb = mongoose.model('data',schema);

//Export module to be used outside model.js
module.exports = Userdb;