//Axios library to use all axios functions 
const axios = require('axios');

//renders main page
exports.homeRoutes = (req,res)=>{
    //make get request to /api/entry
    axios.get('http://localhost:3000/api/entry')
    .then(function(response){
        console.log(response.data)
    res.render('index',{entry:response.data});
})
.catch(err=>{
    res.send(err);
})
}

//render add entry page
exports.add_entry = (req,res)=>{
    res.render('add_entry');
}

//render update page
exports.update_entry = (req,res)=>{
    axios.get('http://localhost:3000/api/entry',{params:{id:req.query.id}})
    .then(function(entrydata){
        res.render("update_entry",{entry:entrydata.data})
    })
    .catch(err=>{
        res.send(err);
    })
}