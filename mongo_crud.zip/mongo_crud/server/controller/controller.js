const { userInfo } = require('os');
var Userdb = require('../model/model');


//create and save new entry
exports.create = (req,res)=>{
//validate requests
if(!req.body){
    res.status(400).send({message: "Content cannot be empty!"});
    return;
    }

    //new entry
    const entry = new Userdb({ 
        first_name:req.body.first_name,
        last_name:req.body.last_name,
        city:req.body.city,
        county:req.body.county,
        state:req.body.state,
        zip:req.body.zip,
        Restaurant:req.body.Restaurant,
        RES_VISITS:req.body.RES_VISITS,
        Webstore_Spend:req.body.Webstore_Spend,
        WEB_VISITS:req.body.WEB_VISITS,
        Age:req.body.Age,
        Married_YN:req.body.Married_YN,
        Income:req.body.Income

    })

    //save new entry
    entry
        .save(entry)
        .then(data=>{
          // res.send(data) 
          res.redirect('/add_entry');
        })

        .catch(err=>{
            res.status(500).send({
                message: err.message || "Some error occured while creating"
            });

        });

}

//retrieve and return results
exports.find = (req, res)=>{


    if(req.query.id){
        const id = req.query.id;

    Userdb.findById(id)
        .then(data=>{
            if(!data){
                res.status(404).send({message: "Not found entry with ID" + id})
            }else{
                res.send(data)
            }
        })
        .catch(err=>{
            res.status(500).send({message: " Error retrieving entry with id"})
        })

    }
    else{
    Userdb.find()
    .then(entry=>{
        res.send(entry)
    })
    .catch(err =>{
        res.status(500).send({message:err.message || " Error Occured retrieving infromation"})
    })
}
}

//update new data 
exports.update = (req,res)=>{
    
    //check there is data to update
    if(!req.body){
        return res
        .status(400)
        .send({message: "Update cannot be empty"})
    }

        //holds data for all parameters 
        const id = req.params.id;
        Userdb.findByIdAndUpdate(id, req.body, {useFindAndModify:false})
            .then(data=> {

                //checks the data requested is found
                if(!data){
                  res.status(404).send({message: `Cannot Update entry with ${id}. Entry not found`})  

                //No errors found send the data out to be updated  
                }else{
                    res.send(data)
                }
            })

            //Catch any errors updating infromation
            .catch(err=>{
                res.status(500).send({message: "Error updating entry information"})
            })
}

//delete data 
exports.delete = (req,res)=>{
    const id = req.params.id;

    //function that find data to delete by id
    Userdb.findByIdAndDelete(id)
        .then(data=>{

            //detect and display any not found errors 
            if(!data){
                res.status(404).send({message:`Cannot Delete id ${id}. ID may be wrong`})

            //No errors found send data and print success message
            }else{
                res.send({
                    message:"Entry Deleted Successfully"
                })
            }

        })

//catch and display any errors
.catch(err => {
    res.status(500).send({
        mesage:"Could not delete Entry with id=" + id
    });
});

}