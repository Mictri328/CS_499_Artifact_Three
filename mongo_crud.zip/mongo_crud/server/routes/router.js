//import expres in constant to use library
const express = require('express');

//imports router variable to direct routes
const route = express.Router();

//imports render and controller file
const services = require('../services/render')
const controller = require('../controller/controller')
/**
 * @description Root Route
 * @method GET /
 */
route.get('/', services.homeRoutes);

/**
 * @description add entry
 * @method GET /add_entry
 */
route.get('/add_entry', services.add_entry);

/**
 * @description update entry
 * @method GET /update_entry
 */
route.get('/update_entry', services.update_entry);


//API
route.post('/api/entry',controller.create)
route.get('/api/entry',controller.find)
route.put('/api/entry/:id',controller.update)
route.delete('/api/entry/:id',controller.delete)

//export routes
module.exports = route