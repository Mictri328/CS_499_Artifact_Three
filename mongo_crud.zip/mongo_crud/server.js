// call express module 
const express = require('express');
//call env module
const dotenv = require('dotenv');
//call morgan module
const morgan = require('morgan');
//call bodyparser module
const bodyparser = require("body-parser");
// call path module
const path = require('path');
//call mongo connect
const connectDB = require('./server/database/connection');


//create app variable
const app = express();

//point to config file
dotenv.config({path :'config.env'})
// port direction constant with default value
const PORT = process.env.PORT || 8080

//log request
app.use(morgan('tiny'));

//mongoDB connection
connectDB();

//parse request to body-parser
app.use(bodyparser.urlencoded({extended:true}))

//set view engine folder
app.set("view engine","ejs")

//load assests
app.use('/css', express.static(path.resolve(__dirname,"assets/css")))
app.use('/img', express.static(path.resolve(__dirname,"assets/img")))
app.use('/js', express.static(path.resolve(__dirname,"assets/js")))


//load routers 
app.use('/', require('./server/routes/router'))

//listner for server port
app.listen(PORT, ()=>{console.log(`Server is running on http://localhost:${PORT}`)});


